import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../../service/employee.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  RegisterEmp: FormGroup;
  constructor(private formBuilder: FormBuilder, private employeeService: EmployeeService,
    private toastr: ToastrService, private router: Router) {
    this.RegisterEmp = this.formBuilder.group({
      Email: ['', [Validators.required]],
      Name: ['', [Validators.required]],
      Department: ['', [Validators.required]],
      Photo: ['', [Validators.required]]

    });
  }
  ngOnInit(): void {
  }

  registeremp() {
    console.log("registeremp");
    this.employeeService.AddEmployees(this.RegisterEmp.value).subscribe(result => {
      localStorage.setItem('userData', JSON.stringify(result));
      this.router.navigate(['/employee']);
      this.toastr.success('Success', 'Employee Created');
    }, (error) => {
      console.log(error);
      this.toastr.error('Failed', 'Invalid Data');
    });

  }
}
