import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../../service/employee.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-employeeupdate',
  templateUrl: './employeeupdate.component.html',
  styleUrls: ['./employeeupdate.component.css']
})
export class EmployeeupdateComponent implements OnInit {

  EditEmp: FormGroup;
  EmpId: number;
  empDetail: any;
  editEmployee: any;
  constructor(private formBuilder: FormBuilder, private employeeService: EmployeeService,
    private toastr: ToastrService, private route: ActivatedRoute, private router: Router) {

    this.EditEmp = this.formBuilder.group({
      Email: ['', [Validators.required]],
      Name: ['', [Validators.required]],
      Department: ['', [Validators.required]],
      Photo: ['', [Validators.required]]

    });

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.EmpId = params.id;
      this.getEmpById(this.EmpId);
    })
  }


  getEmpById(id) {
    this.employeeService.GetEmployeebyid(id).subscribe(data => {
      console.log(data);
      this.editEmployee = data;
      this.EditEmp.setValue({
        Email: this.editEmployee.email,
        Name: this.editEmployee.name,
        Department: this.editEmployee.department,
        Photo: this.editEmployee.photo
      });
    });
  }


  close(){
    this.router.navigate(['/employee']);
  }
  

  editemp() {
    console.log(this.EditEmp.value);
    this.employeeService.UpdateEmployees(this.EditEmp.value, this.EmpId).subscribe(result => {
      console.log(result);
      localStorage.setItem('userData', JSON.stringify(result));
      this.router.navigate(['/employee']);
      this.toastr.success('Success', 'Employee Updated');
    }, (error) => {
      console.log(error);
      this.toastr.error('Failed', 'Invalid Data');
    });


  }
}
