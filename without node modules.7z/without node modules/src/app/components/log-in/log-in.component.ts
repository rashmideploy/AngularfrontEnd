import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {  
  loginForm: FormGroup;
	constructor(private formBuilder: FormBuilder, private userService:AuthService , private toastr: ToastrService,private router: Router) {
		this.loginForm = this.formBuilder.group({
			email: ['', [Validators.required,userService.emailValidator]],
			password: ['', [Validators.required, userService.passwordValidator]]
		});
	}
  ngOnInit(): void {
  }
// Initicate login
doLogin() {
  this.userService.doLogin(this.loginForm.value).subscribe(result => {
    console.log(result);
    localStorage.setItem('userData', JSON.stringify(result));

    this.router.navigate(['/employee']);
    this.toastr.success('Success', 'Logged In Successfully');
  }, (error) => {
    console.log(error);
    this.toastr.error('Failed', 'Invalid Credentials');
  });
  
}

}
