import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  RegisterForm: FormGroup;
	constructor(private formBuilder: FormBuilder, private userService:AuthService , private toastr: ToastrService, private router:Router) {
		this.RegisterForm = this.formBuilder.group({
			email: ['', [Validators.required,userService.emailValidator]],
			password: ['', [Validators.required, userService.passwordValidator]]
		});
	}
  ngOnInit(): void {
  }

close(){
  this.router.navigate(['/']);
}

register() {
  this.userService.register(this.RegisterForm.value).subscribe(result => {
    console.log(result);
    //localStorage.setItem('userData', JSON.stringify(result));
    // this.router.navigate(['/']);
    this.toastr.success('Success', 'User Created');
  }, (error) => {
    console.log(error);
    this.toastr.error('Failed', 'Invalid Data');
  });
  
}



}
