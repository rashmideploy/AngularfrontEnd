import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../service/employee.service';
import { ToastrService } from 'ngx-toastr';
import { Router, Routes } from '@angular/router';



@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  updateEmployeeList:any[];
  Emplist: any;
  constructor(private emplistService:EmployeeService, private toastr:ToastrService ,private router: Router) { }

  getallemployees()
  {
    this.emplistService.GetEmployees().subscribe(result=>{
      console.log(result);
      localStorage.setItem('empData', JSON.stringify(result));
          this.Emplist = result;
		},(error)=>{
			console.log(error);
		});
  }

  ngOnInit(): void {
    this.getallemployees();
  }

  // Delete a student with its index
	deleteemp(emp) {
		// get confirm box for confirmation
		const r = confirm('Are you sure?');
		if (r === true) {
      
      const EmployeeDelete=this.emplistService.delEmployees(emp).subscribe(result=>{
        console.log(result);
        this.getallemployees();
        this.toastr.success('Success', 'Employee Deleted');
      },(error)=>{
        console.log(error);
        this.toastr.error('Failed', 'Operation Failed');
      });
    
    }

		
	}
  update(e){
    console.log(e);
     this.updateEmployeeList = e.id;
  }

}
