import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  API_URI = 'https://localhost:44355';

  constructor(private http: HttpClient) { }

  doLogin(data) {
    console.log(data);
    return this.http.post(this.API_URI + '/api/admin', data);
  }

  register(data) {
    console.log(data);
    return this.http.post(this.API_URI + '/api/Register', data);
  }

  emailValidator(control) {
    // RFC 2822 compliant regex
    if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
      return null;
    } else {
      return { 'invalidEmailAddress': true };
    }
  }



  passwordValidator(control) {
    // {6,100}           - Assert password is between 6 and 100 characters
    // (?=.*[0-9])       - Assert a string has at least one number
    if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{3,100}$/)) {
      return null;
    } else {
      return { 'invalidPassword': true };
    }
  }


  // doLogin(data) {
  //   if (data.email === "ras@gmail.com" && data.password === "admin123") {
  //     return {
  //       code: 200,
  //       message: "Login Successful",
  //       data: data
  //     };
  //   } else {
  //     return {
  //       code: 503,
  //       message: "Invalid Credentials",
  //       data: null
  //     };
  //   }
  // }
}
