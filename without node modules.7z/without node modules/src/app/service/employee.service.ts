import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  API_URI = 'https://localhost:44355';
  constructor(private http: HttpClient) { }


  GetEmployees() {
    return this.http.get(this.API_URI + '/api/Employees');
  }

  AddEmployees(data) {
    console.log(data);
    return this.http.post(this.API_URI + '/api/Employees', data);
  }
  delEmployees(data) {
    console.log(data);

    return this.http.delete(this.API_URI + '/api/Employees' + '/' + data.id);
  }
  UpdateEmployees(data, id) {
    return this.http.put(this.API_URI + '/api/Employees' + '/' + id, data);
  }
  GetEmployeebyid(id: number) {
    return this.http.get(this.API_URI + '/api/Employees' + '/' + id);
  }



}